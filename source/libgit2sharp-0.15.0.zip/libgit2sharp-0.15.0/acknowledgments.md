LibGit2Sharp is making use of the following OSS projects:
- [tar-cs](http://code.google.com/p/tar-cs/) project by Vladimir Vasiltsov and is used under the [BSD license](http://code.google.com/p/tar-cs/source/browse/trunk/COPYING)
