﻿namespace LibGit2Sharp.Core
{
    internal enum GitDirection
    {
        Fetch = 0,
        Push = 1
    }
}
