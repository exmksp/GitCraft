namespace LibGit2Sharp.Core
{
	internal static class NativeDllName
	{
		public const string Name = "git2-65e9dc6";
	}
}
